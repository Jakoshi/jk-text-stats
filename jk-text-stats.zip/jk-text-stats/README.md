#Usage

This Plugin enables you to use the shortcode `[jk-text-stats]`.

This shortcode will display a table with stats for the content of a wordpress page.

You can use it in your template files (such as single.php) like this:

```php
<?php 
echo do_shortcode('[jk-text-stats]');
?>
```
